#include "Dragon.h"

Dragon::Dragon() : BattleCard("Dragon", 25, 1000, 100) {}