#ifndef DRAGON_H
#define DRAGON_H

#include "BattleCard.h"

class Dragon : public BattleCard {

public:
    Dragon();
};

#endif //DRAGON_H
