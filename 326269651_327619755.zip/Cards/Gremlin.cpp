#include "Gremlin.h"

Gremlin::Gremlin() : BattleCard("Gremlin", 5, 2, 10) {}