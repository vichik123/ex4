#ifndef GREMLIN_H
#define GREMLIN_H

#include "BattleCard.h"

class Gremlin : public BattleCard {

public:
    Gremlin();
};

#endif //GREMLIN_H
