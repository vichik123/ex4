#include "Witch.h"

Witch::Witch() : BattleCard("Witch", 11, 2, 10) {}
