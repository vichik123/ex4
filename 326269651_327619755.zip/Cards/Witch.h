#ifndef WITCH_H
#define WITCH_H

#include "BattleCard.h"

class Witch : public BattleCard {

public:
    Witch();
};

#endif //WITCH_H
