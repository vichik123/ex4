#include "Healer.h"

Healer::Healer(std::string name) : Player(std::move(name), "Healer") {}