#include "Ninja.h"

Ninja::Ninja(std::string name) : Player(std::move(name), "Ninja") {}