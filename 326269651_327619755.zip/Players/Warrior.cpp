#include "Warrior.h"

Warrior::Warrior(std::string name) : Player(std::move(name), "Warrior") {}